import React from 'react';
import { View } from 'react-native';

export default () => (
  <View style={{ width: 300, height: 200, backgroundColor: 'skyblue' }} />
);
